LONG GMAIL 10PH - RENDER

Files: app.py, requirements.txt
Build command: pip install -r requirements.txt
Start command: gunicorn app:app
Environment variable: SECRET_KEY = a long random secret string

Important: this app uses per-browser signed session cookies; each browser gets a separate mailbox session. The email provider is third-party 1secmail, not real Gmail. Do not use for sensitive accounts or important verification. Third-party service rules/availability may change.
